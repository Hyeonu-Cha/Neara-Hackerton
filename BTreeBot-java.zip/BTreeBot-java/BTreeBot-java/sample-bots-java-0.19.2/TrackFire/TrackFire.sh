#!/bin/sh
java -cp ../lib/* TrackFire.java 
