#!/bin/sh
java -cp ../lib/* RamFire.java 
