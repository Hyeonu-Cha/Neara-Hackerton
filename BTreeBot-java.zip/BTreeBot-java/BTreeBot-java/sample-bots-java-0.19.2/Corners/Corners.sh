#!/bin/sh
java -cp ../lib/* Corners.java 
