import java.net.URI

rootProject.name = "tankroyale"

//sourceControl {
//    gitRepository(URI.create("https://github.com/Typiqally/kt-behaviour-tree.git")) {
//        producesModule("com.tpcly:behaviourtree")
//    }
//}
