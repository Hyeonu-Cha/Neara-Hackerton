package org.example;

import dev.robocode.tankroyale.botapi.Bot;
import dev.robocode.tankroyale.botapi.BotInfo;

public class Crazy extends Bot {
    public Crazy() {
        super(BotInfo.fromFile("Crazy.json"));
    }

    @Override
    public void run() {
        while (isRunning()) {
            turnRight(45.0);
            turnGunLeft(360.0);
        }
    }
}
