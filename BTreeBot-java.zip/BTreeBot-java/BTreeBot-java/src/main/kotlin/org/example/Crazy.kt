package org.example

fun main() {
    Crazy().start()
}
